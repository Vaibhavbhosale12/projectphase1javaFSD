import org.cisco.lockedmeapplication.welcome.WelcomeScreen;

public class LockedMeImpl {

        public static void main(String[] args)  {
            WelcomeScreen welcome = new WelcomeScreen();
            welcome.introScreen();
            welcome.GetUserInput();

    }
}
