package org.cisco.lockedmeapplication.services;

import org.cisco.lockedmeapplication.filemainscreen.FileOptions;
public class DashboardService {
    public static void setCurrentScreen()   {
        FileOptions file = new FileOptions();
        file.GetUserInput();
    }
}
